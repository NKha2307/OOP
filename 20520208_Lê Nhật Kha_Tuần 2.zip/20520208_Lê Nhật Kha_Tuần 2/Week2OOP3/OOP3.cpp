﻿#include "TestCandidate.h"

int main()
{
	TestCandidate _tDanhSach;
	_tDanhSach.NhapDanhSachSinhVien();
	_tDanhSach.XuatDanhSachSinhVien();
	_tDanhSach.DeleteDanhSach();
	return 0;
}