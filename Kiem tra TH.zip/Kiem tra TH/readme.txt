Họ và tên: Lê Nhật Kha
Mã số sinh viên: 20520208
Mã lớp: IT002.L29.1
Đề thi số: 01
