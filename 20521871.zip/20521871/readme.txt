Họ và tên: Nguyễn Hữu Minh Tâm
Mã số sinh viên: 20521871
Mã lớp: IT002.L29.2
Đề thi số: 02
