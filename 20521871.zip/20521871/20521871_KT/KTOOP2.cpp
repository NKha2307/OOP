#include "GiangVienChinh.h"
#include "TroGiang.h"

int NhanSu::SoLuong = 0;
int GiangVienChinh::SoLuong = 0;
int TroGiang::SoLuong = 0;

int main()
{
	cout << "Nhap so luong nhan su: ";
	int SoLuong; cin >> SoLuong;
	long long TongLuong = 0;
	NhanSu** DanhSach = new NhanSu*[SoLuong];
	for (int i = 0; i < SoLuong; ++i)
	{
		cout << "Nhap thong tin nhan su " << i + 1 << endl;
		cout << "Nhap loai nhan su (0 la giang vien cao cap, 1 la giang vien chinh, 2 la tro giang): ";
		int x; cin >> x;
		if (x == 0) DanhSach[i] = new NhanSu;
		else if (x == 1)
		{
			DanhSach[i] = new GiangVienChinh;
			--NhanSu::SoLuong;
		}
		else 
		{
			DanhSach[i] = new TroGiang;
			--NhanSu::SoLuong;
		}
		DanhSach[i]->inputNhanSu();
		TongLuong += DanhSach[i]->getLuong();
	}
	for (int i = 0; i < SoLuong; ++i)
	{
		cout << "Thong tin nhan su " << i + 1 << endl;
		DanhSach[i]->outputNhanSu();
	}
	cout << "Tong so tien luong: " << TongLuong << endl;
	cout << "So luong Giang vien cao cap: " << NhanSu::SoLuong << endl;
	cout << "So luong Giang vien chinh: " << GiangVienChinh::SoLuong << endl;
	cout << "So luong Tro giang: " << TroGiang::SoLuong << endl;
	delete[]DanhSach; 
	return 0;
}