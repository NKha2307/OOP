#pragma once
#include "NhanSu.h"

class GiangVienChinh : public NhanSu
{
protected:
	int SoNgayDay;
public:
	static int SoLuong;
	GiangVienChinh() { ++this->SoLuong; }
	virtual~GiangVienChinh(){}
	long long getLuong();
	void inputNhanSu();
};

