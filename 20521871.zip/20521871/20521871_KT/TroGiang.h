#pragma once
#include "NhanSu.h"

class TroGiang : public NhanSu
{
protected:
	int SoGioDay;
public:
	static int SoLuong;
	TroGiang() { ++this->SoLuong; }
	virtual~TroGiang() {}
	long long getLuong();
	void inputNhanSu();
};

