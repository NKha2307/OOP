#pragma once
#include <iostream>
#include <string>
using namespace std;
#define LCB 1871

class NhanSu
{
protected:
	string HoVaTen;
	char GioiTinh;
	int HocVi;
	long long LuongCoBan;
	long long Luong;
public:
	static int SoLuong;
	NhanSu() { ++this->SoLuong; }
	virtual~NhanSu(){}
	virtual long long getLuong();
	virtual void inputNhanSu();
	virtual void outputNhanSu();
};

