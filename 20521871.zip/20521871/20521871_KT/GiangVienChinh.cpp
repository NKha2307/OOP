#include "GiangVienChinh.h"

void GiangVienChinh::inputNhanSu()
{
	NhanSu::inputNhanSu();
	cout << "Nhap so ngay day: ";
	cin >> this->SoNgayDay;
}
long long GiangVienChinh::getLuong()
{
	this->Luong = (long long)this->SoNgayDay * 1000000;
	if (this->SoNgayDay > 15)
		this->Luong += (long long) (this->SoNgayDay - 15) * 1000000;
	return this->Luong;
}