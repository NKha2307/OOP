#include "NhanSu.h"

void NhanSu::inputNhanSu()
{
	cin.ignore();
	cout << "Nhap ho va ten: ";
	getline(cin, this->HoVaTen);
	cout << "Nhap gioi tinh (F la female, M la male): ";
	cin >> this->GioiTinh;
	cout << "Nhap hoc vi (0 la Ky su, 1 la Thac si, 2 la Tien si): ";
	cin >> this->HocVi;
	this->LuongCoBan = LCB;
}
void NhanSu::outputNhanSu()
{
	cout << "Ho va ten: " << this->HoVaTen << endl;
	cout << "Gioi tinh: ";
	if (this->GioiTinh == 'F') cout << "Nu\n";
	else cout << "Nam\n";
	cout << "Hoc vi: ";
	switch (this->HocVi)
	{
	case 0:
		cout << "Ky su\n";
		break;
	case 1: 
		cout << "Thac si\n";
		break;
	case 2:
		cout << "Tien si\n";
	}
	cout << "Luong: " << this->getLuong() << endl;
}
long long NhanSu::getLuong()
{
	switch (this->HocVi)
	{
	case 0: 
		this->Luong = (long long)this->LuongCoBan * 6 / 5;
		break;
	case 1:
		this->Luong = (long long)this->LuongCoBan * 3 / 2;
		break;
	case 2:
		this->Luong = (long long)this->LuongCoBan * 2;
	}
	return this->Luong;
}