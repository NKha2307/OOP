#include "TroGiang.h"

void TroGiang::inputNhanSu()
{
	NhanSu::inputNhanSu();
	cout << "Nhap so gio day: ";
	cin >> this->SoGioDay;
}
long long TroGiang::getLuong()
{
	this->Luong = (long long)this->SoGioDay * 130000;
	if (this->SoGioDay > 40)
		this->Luong *= 1.1;
	return this->Luong;
}